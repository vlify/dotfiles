-- lua/plugins/git.lua
return {
    { "tpope/vim-fugitive" },
    { "lewis6991/gitsigns.nvim" },
}

